// ===================================================
// Name Matching
// ===================================================

// Also consider searching last name, first name then just using first option?
// don't like it because it might lead to incorrect matches

const TEST_NAME_MATCHING = false; // REMEMBER TO SET TO FALSE BEFORE BUILDING
const nameMatchTests = [
  { a: "Dr. John Smith",          b: "John Smith",          expected: true,  note: "prefix removed" },
  { a: "John A. Smith",           b: "John Smith",          expected: true,  note: "middle initial ignored" },
  { a: "John Smith Jr.",          b: "John Smith",          expected: true,  note: "suffix ignored" },
  { a: "John Smith-Henry",        b: "John Smith Henry",    expected: true,  note: "hyphenation/spacing" },
  { a: "John Henry-Smith",        b: "John Smith-Henry",    expected: false,  note: "compound last-name reorder" },
  { a: "Alexander Smith",         b: "Alex Smith",          expected: true,  note: "nickname/alias" },
  { a: "André Lefèvre",           b: "Andre Lefevre",       expected: true,  note: "diacritics normalized" },
  { a: "Jonathan",                b: "Jonatahn",            expected: true,  note: "minor transposition/typo" },
  { a: "Michael",                 b: "Mike",                expected: true,  note: "minor transposition/typo" },
  { a: "John Smith",              b: "Jane Smith",          expected: false, note: "different given name" },
  { a: "John Smith",              b: "John Smythe",         expected: false, note: "different family name" },
  { a: "J. Smith",                b: "John A. Smith",       expected: false, note: "initials ambiguous" },
  { a: "Dr",                      b: "John",                expected: false, note: "only prefix / insufficient" },
  { a: "",                        b: "John Smith",          expected: false, note: "empty input" },
  { a: "Alice Johnson",           b: "Robert Brown",        expected: false, note: "completely different" },
  { a: "Carlos Ochoa-Cardenas",   b: "Carlos Ochoa",        expected: true,  note: "compound last name" },
  { a: "Dr. Emily Davis",          b: "Emily Davis",         expected: true,  note: "prefix removed" },
  { a: "Dr. Emily Davis",          b: "Dr. Emily Davis",     expected: true,  note: "same name with prefix" },
  { a: "Emily Davis",              b: "Emily Davis",         expected: true,  note: "same name without prefix" },
  { a: "Jaques St Pierre",          b: "Jacques St Pierre",   expected: true,  note: "minor typo in given name" },
  { a: "Jaques St Pierre",          b: "Jaques StPierre",   expected: true,  note: "splitting of compound last name" },
  { a: "Jaques St Pierre",          b: "Jaques StMierre",   expected: false,  note: "last names different" },
  { a: "Carlogs Blath llkjlk Pierre",          b: "Carlogs Pierre",   expected: true,  note: "compound last name" },
  { a: "Timothy Alcon",          b: "Tim Alcon",   expected: true,  note: "real world first name alias" },
];

// Tables and suffixes from https://github.com/craj/name-match/blob/main/src/name-normalizer.js
const PREFIXES = ['mr', 'mrs', 'ms', 'miss', 'dr', 'prof', 'rev', 'hon'];
const SUFFIXES = ['jr', 'sr', 'ii', 'iii', 'iv', 'v', 'md', 'phd', 'esq'];
const LAST_NAME_PREFIXES = ['de', 'van', 'von', 'le', 'la', 'di', 'del', 'o', 'mc', 'mac', 'st'];
const NAME_TO_ALIAS = {
  'william': ['will'],
  'robert': ['rob', 'bob', 'bobby', 'robbie'],
  'richard': ['rick', 'dick', 'richie', 'ricky'],
  'michael': ['mike'],
  'joseph': ['joe', 'joey'],
  'thomas': ['tom', 'tommy'],
  'christopher': ['chris'],
  'charles': ['chuck', 'charlie'],
  'daniel': ['dan'],
  'matthew': ['matt', 'matty', 'mathew'],
  'anthony': ['tony'],
  'steven': ['steve', 'stevie'],
  'kenneth': ['ken', 'kenny'],
  'edward': ['ed', 'eddie', 'ted', 'teddy'],
  'donald': ['don', 'donny'],
  'elizabeth': ['liz', 'lizzy', 'beth', 'betty', 'eli'],
  'jennifer': ['jen', 'jenny'],
  'katherine': ['kathy', 'kate', 'katie', 'katy'],
  'margaret': ['maggie', 'meg', 'megan', 'peggy'],
  'patricia': ['pat', 'patty', 'trish'],
  'deborah': ['deb', 'debbie'],
  'jessica': ['jess', 'jessie'],
  'sandra': ['sandy'],
  'barbara': ['barb', 'barbie'],
  'stephanie': ['steph', 'stephy'],
  'victoria': ['vicky', 'tori'],
  'jonathan': ['jon', 'jonny'],
  'nicholas': ['nick', 'nicky'],
  'jeffrey': ['jeff'],
  'benjamin': ['ben', 'benny'],
  'timothy': ['tim', 'timmy'],
  'gregory': ['greg', 'gregg'],
  'raymond': ['ray'],
  'samuel': ['sam', 'sammy'],
  'andrew': ['andy', 'drew'],
  'alexander': ['alex', 'al'],
  'david': ['dave', 'davey'],
  'joshua': ['josh']
};

// scheduler key to RMP names
const MATCH_TABLE = {
    'Alex Guyer': ['Alexander Guyer'],
    'Tim Alcon': ['Timothy Alcon'],
    'Kara Trummel Obermire': ['Kara Obermire'],
    'Matthew Kenison': ['Matthew Kenison'],
    'Carlos Ochoa': ['Carlos Ochoa-Cardenas'],
}

// reverse lookup
const ALIAS_TO_NAME = {};
for (const [name, aliases] of Object.entries(NAME_TO_ALIAS)) {
    for (const alias of aliases) {
        if (!ALIAS_TO_NAME[alias]) {
            ALIAS_TO_NAME[alias] = [];
        }
        ALIAS_TO_NAME[alias].push(name);
    }
}


function jaroWinklerSimilarity(s1, s2) {
    const PREFIX_SCALE = 0.1; // scaling factor for common prefix
    const PREFIX_LENGTH = 4; // maximum prefix length to consider
    const JW_THRESHOLD = 0.7; // threshold for applying the prefix adjustment

    if (s1 === s2) return 1.0;
    if (!s1 || !s2) return 0.0;
    const len1 = s1.length;
    const len2 = s2.length;
    const maxDist = Math.max(0, Math.floor(Math.max(len1, len2) / 2) - 1);
    let matches = 0;
    const hash1 = new Array(len1).fill(false);
    const hash2 = new Array(len2).fill(false);
    for (let i = 0; i < len1; i++) {
        const start = Math.max(0, i - maxDist);
        const end = Math.min(i + maxDist + 1, len2);
        for (let j = start; j < end; j++) {
            if (hash2[j]) continue;
            if (s1[i] === s2[j]) {
                hash1[i] = true;
                hash2[j] = true;
                matches++;
                break;
            }
        }
    }
    if (matches === 0) return 0.0;
    let transpositions = 0;
    let ptr = 0;
    for (let i = 0; i < len1; i++) {
        if (!hash1[i]) continue;
        while (!hash2[ptr] && ptr < len2) {
            ptr++;
        }
        if (s1[i] !== s2[ptr]) {
            transpositions++;
        }
        ptr++;
    }
    transpositions /= 2;

    const jaro = (matches / len1 + matches / len2 + (matches - transpositions) / matches) / 3.0;

    const prefixLength = Math.min(PREFIX_LENGTH, Math.min(s1.length, s2.length));
    let prefix = 0;
    for (let i = 0; i < prefixLength; i++) {
        if (s1[i] === s2[i]) {
            prefix++;
        } else {
            break;
        }
    }
    
    if (jaro < JW_THRESHOLD) {
        return jaro;
    }
    return Math.min(1.0, jaro + PREFIX_SCALE * prefix * (1 - jaro));
}

class Name {
    // TODO: make constructor gracefully fail if it can't parse name pieces
    constructor(nameString) {
        // names are all lowercase, trimmed, with basic variation in name table 
        // and get rid of punctuation and make accents closest ascii.
        // tbh scheduler and rmp might not support non-ascii names but just in case

        this.rawName = nameString;
        this.prefix = null;
        this.firstName = null;
        this.middleName = null;
        this.lastName = null;
        this.suffix = null;
        if (!nameString) {
            console.warn("RMP-OSU: Name constructor called with null or empty string.");
            return;
        }

        // overall parsing steps
        // everything is trimmed lowercased and asciid
        //
        // ex: "  Dr. John St Smith-Henry Jr."

        nameString = nameString.toLowerCase();
        nameString = nameString.trim();
        nameString = Name.removeAccents(nameString);

        this.prefix = Name.extractPrefix(nameString);
        if (this.prefix) {
            nameString = nameString.replace(this.prefix, "").trim();
        }
        nameString = Name.removePeriods(nameString);
        nameString = nameString.trim();
        if (nameString === "") {
            console.warn("RMP-OSU: Name constructor called with name string that only contains a prefix.", this.rawName, nameString);
            return
        }

        // in the case of non defined prefix its kinda over
        // resolves all firstNames to cononical name
        const rawFirstName = nameString.split(' ')[0];
        this.firstName = Name.getBasicFirstName(rawFirstName);
        nameString = nameString.replace(rawFirstName, '').trim();
        if (nameString === "") {
            console.warn("RMP-OSU: Name constructor called with name string that contains nothing past first name.", this.rawName, nameString);
            return
        }

        this.suffix = Name.extractSuffix(nameString);
        nameString = nameString.replace(" " + this.suffix, "").trim();

        // replace hyphen with space
        nameString = nameString.replace('-', ' ').trim();
        nameString = Name.removePunctuation(nameString);

        const lastNames = nameString.split(' ');
        if (lastNames.length > 1) {
            this.middleName = lastNames[0].trim();
            this.lastName = lastNames.slice(1).join(" ").trim();
        }
        else {
            this.middleName = null;
            this.lastName = lastNames[0].trim();
        }
    }

    /**
     * Check if the name is valid, should always check after construction.
     * @returns True if firstName and lastName are not null.
     */
    valid() {
        return this.firstName != null && this.lastName != null;
    }

    // Check test table for equation expectations
    similarTo(otherName) {
        // Check raw names in match table first
        if (otherName == null) return false;
        if (MATCH_TABLE[this.rawName]) {
            return MATCH_TABLE[this.rawName].includes(otherName.rawName);
        }
        let score = 0;
        score += jaroWinklerSimilarity(this.firstName, otherName.firstName) * 1.0;
        // console.log("RMP-OSU: Fname score", score, this.firstName, otherName.firstName);
        if (this.middleName && otherName.middleName) {
            score += jaroWinklerSimilarity(this.middleName, otherName.middleName) * 1.0;
        }
        // console.log("RMP-OSU: Mname score", score, this.middleName, otherName.middleName);
        score += jaroWinklerSimilarity(this.lastName, otherName.lastName) * 3;
        // console.log("RMP-OSU: Lname score", score, this.lastName, otherName.lastName);
        if (this.prefix && this.prefix === otherName.prefix) score += 0.25;
        // console.log("RMP-OSU: Prefix score", score, this.prefix, otherName.prefix);
        if (this.suffix && this.suffix === otherName.suffix) score += 1;
        // console.log("RMP-OSU: Suffix score", score, this.suffix, otherName.suffix);
        return score >= 3.8;
    }
    // All these return the modified string or same string if no changes can be made
    static removeAccents(nameString) {
        if (!nameString) return nameString;
        nameString = nameString.replace(/á|à|â|ã|ä/g, 'a');
        nameString = nameString.replace(/é|è|ê|ë/g, 'e');
        nameString = nameString.replace(/í|ì|î|ï/g, 'i');
        nameString = nameString.replace(/ó|ò|ô|õ|ö/g, 'o');
        nameString = nameString.replace(/ú|ù|û|ü/g, 'u');
        nameString = nameString.replace(/ç/g, 'c');
        nameString = nameString.replace(/ñ/g, 'n');
        return nameString;
    }
    static removePunctuation(nameString) {
        if (!nameString) return nameString;
        return nameString.replace(/[^a-z\s]/g, '');
    }
    static removePeriods(nameString) {
        if (!nameString) return nameString;
        return nameString.replace(/\./g, '');
    }
    static extractPrefix(nameString) {
        if (!nameString) return nameString;
        nameString = Name.removePunctuation(nameString);
        const prefix = nameString.split(' ')[0];
        if (PREFIXES.includes(prefix.toLowerCase())) {
            return prefix;
        }
        return null;
    }
    static extractSuffix(nameString) {
        if (!nameString) return nameString;
        const parts = nameString.split(' ');
        if (parts.length === 0) return null;
        const suffix = parts[parts.length - 1];
        if (SUFFIXES.includes(suffix.toLowerCase())) {
            return suffix;
        }
        return null;
    }
    static getBasicFirstName(firstName) {
        if (!firstName) return firstName;
        if (ALIAS_TO_NAME.hasOwnProperty(firstName.toLowerCase())) {
            return ALIAS_TO_NAME[firstName.toLowerCase()][0];
        }
        return firstName;
    }
    // TODO fix but its probably not used
    toString() {
        const parts = [];
        if (this.prefix) parts.push(this.prefix);
        if (this.firstName) parts.push(this.firstName);
        if (this.middleName) parts.push(this.middleName);
        if (this.lastName) parts.push(this.lastName);
        if (this.suffix) parts.push(this.suffix);
        return parts.join(' ');
    }
}

if (TEST_NAME_MATCHING) {
    console.warn("RMP-OSU: Running name matching tests...");
    for (const test of nameMatchTests) {
        const nameA = new Name(test.a);
        const nameB = new Name(test.b);
        const result = nameA.similarTo(nameB);
        console.warn(`RMP-OSU: ${test.a} parsed as`, nameA);
        console.warn(`RMP-OSU: ${test.b} parsed as`, nameB);
        console.warn(`RMP-OSU: Similarity between ${test.a} and ${test.b}: ${result}`);
        console.assert(result === test.expected, `RMP-OSU: Test failed for ${test.a} vs ${test.b}: expected ${test.expected}, got ${result}. Note: ${test.note}`);
    }
}

// ===================================================
// Content Script
// ===================================================

const profDataCache = {}
const crnToInstructorCache = {}
const classNameToSectionDataCache = {}

// Use scheduler.rawName as key
function getProfDataCache(key) {
    return profDataCache[key];
}
function setProfDataCache(key, value) {
    profDataCache[key] = value;
}

function getCrnToInstructorCache(key) {
    return crnToInstructorCache[key];
}
function setCrnToInstructorCache(key, value) {
    crnToInstructorCache[key] = value;
}

function getClassNameToSectionDataCache(key) {
    return classNameToSectionDataCache[key];
}
function setClassNameToSectionDataCache(key, value) {
    classNameToSectionDataCache[key] = value;
}


class ProfessorData {
    // scheduleName is the canonical name for display and reference
    constructor(rmpName, scheduleName, avgRating, numRatings, wouldTakeAgainPercent, avgDifficulty, legacyId) {
        this.rmpName = rmpName; 
        this.scheduleName = scheduleName; 
        this.avgRating = avgRating;
        if (avgRating != null) {
            this.avgRating = avgRating.toPrecision(2);
        }
        this.numRatings = numRatings;
        this.wouldTakeAgainPercent = wouldTakeAgainPercent;
        this.avgDifficulty = avgDifficulty;
        if (avgDifficulty != null) {
            this.avgDifficulty = avgDifficulty.toPrecision(2);
        }
        this.legacyId = legacyId;
    }
    getProfLink() {
        if (this.legacyId) {
            return `https://www.ratemyprofessors.com/professor/${this.legacyId}`;
        }
        else {
            return null;
        }
    }
    getScheduleName() {
        if (!this.scheduleName) {
            return null;
        }
        return this.scheduleName.rawName;
    }
}

function getProfessorDescriptionElement() {
    return document.querySelector(".instructor-detail");
}

// // could be unperformant on large lists? use sparingly
// function getProfessorElementsInClassPreview() {
//     const results = document.querySelectorAll('[class^="result__link"]');
//     console.log("RMP-OSU: Found " + results.length + " class preview result elements.");
//     const instructorElements = Array.from(results).map(result => {
//         return result.querySelector('.result__flex--9.text--right');
//     });
//     console.log(instructorElements);
//     return instructorElements;
// }


async function makeProfessorData(schedulerName) {
    if (schedulerName == null || schedulerName.trim() === "") {
        console.log("RMP-OSU: No professor name provided");
        return null;
    }
    const cached = getProfDataCache(schedulerName);
    if (cached) {
        console.log("RMP-OSU: Returning cached data for " + schedulerName);
        return cached;
    }
    console.log("RMP-OSU: Requesting RMP data for " + schedulerName);
    const gqlQuery = `
        query NewSearch($query: TeacherSearchQuery!) {
            newSearch {
                teachers(
                    query: $query,
                    first: 5
                ) {
                    edges {
                        node {
                            avgDifficulty
                            avgRating
                            firstName
                            lastName
                            numRatings
                            wouldTakeAgainPercent
                            legacyId
                        }
                    }
                }
            }
        }
    `;

    // DOES NOT WORK RETURNS BAD RESULTS
    // // thanks ansel for "lastname, first" idea
    // // don't know if it actually makes a difference
    // // and adding comma breaks most querys for some reason
    // let searchName = schedulerName.split(" ");
    // searchName = `${searchName.slice(1).join(" ")} ${searchName[0]}`;

    const response = await chrome.runtime.sendMessage({
        type: "fetchRequest",
        method: "POST",
        url: "https://www.ratemyprofessors.com/graphql",
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            query: gqlQuery,
            variables: {
                query: {
                    text: schedulerName,
                    schoolID: "U2Nob29sLTc0Mg=="
                }
            }
        })
    })
    if (!response.success) {
        console.error("RMP-OSU: Failed to get a response for " + schedulerName + ": " + response.error);
        return null;
    }
    const gqlResponse = JSON.parse(response.data);
    if (gqlResponse.errors) {
        console.error("RMP-OSU: GraphQL error(s) found in JSON response while fetching RMP data for " + schedulerName + ": " + gqlResponse.errors.map(e => e.message).join(", "));
        return null;
    }
    const rmpTeachers = gqlResponse.data.newSearch.teachers.edges;
    if (rmpTeachers.length === 0) {
        console.log("RMP-OSU: No teachers found in GraphQL query for " + schedulerName);
        return null;
    }
    // TODO: Make amount of results to match configureable
    for (let i = 0; i < rmpTeachers.length; i++) {
        const rmpTeacher = rmpTeachers[i].node;
        const rmpName = new Name(`${rmpTeacher.firstName} ${rmpTeacher.lastName}`);
        const schedlName = new Name(schedulerName);
        // this is orientation in match table
        const probablySame = schedlName.similarTo(rmpName);
        if (!probablySame) {
            continue;
        }
        const profData = new ProfessorData(
            rmpName,
            schedlName,
            rmpTeacher.avgRating,
            rmpTeacher.numRatings,
            rmpTeacher.wouldTakeAgainPercent,
            rmpTeacher.avgDifficulty,
            rmpTeacher.legacyId
        );
        console.log(`RMP-OSU: Found matching RMP data for ${schedulerName} with name ${rmpTeacher.firstName} ${rmpTeacher.lastName}`, profData);
        setProfDataCache(schedlName.rawName, profData);
        return profData;
    }
    console.log("RMP-OSU: No matching RMP data found for " + schedulerName);
    return null;
}

function createRatingElement(profData, schedulerName = null) {
    const ratingEl = document.createElement("div");
    ratingEl.style.marginTop = "5px";
    ratingEl.style.fontSize = "14px";
    let text = "";
    if (profData != null && profData.legacyId != null && profData.avgRating != null && profData.numRatings != null) {
        text = `<a href="${profData.getProfLink()}" target="_blank"><strong>${schedulerName}</strong></a>  ${profData.avgRating}⭐ (${profData.numRatings} ratings)`;
        if (profData.numRatings == 1) {
            text = `<a href="${profData.getProfLink()}" target="_blank"><strong>${schedulerName}</strong></a>  ${profData.avgRating}⭐ (${profData.numRatings} rating)`;
        }
        if (profData.numRatings == 0) {
            text = `<a href="${profData.getProfLink()}" target="_blank"><strong>${schedulerName}</strong></a> (No ratings)`;
        }        
    }        
    else {
        console.log("RMP-OSU: No RMP match for " + schedulerName);
        text = `<a title="Search for name on RateMyProfessor" href="https://www.ratemyprofessors.com/search/professors/742?q=${encodeURIComponent(schedulerName)}" target="_blank"><strong> ${schedulerName}</strong></a> (No RMP Match)`;
    }
    ratingEl.innerHTML = text;
    return ratingEl;
}

async function addRMPToClassDescription() {
    const profElement = getProfessorDescriptionElement();
    if (!profElement || profElement.length === 0) return;
    if (profElement.classList.contains("rmp-osu-injected")) return;
    const schedulerProfName = profElement.textContent.trim();
    if (schedulerProfName == "") return;
    console.log("RMP-OSU: Found instructor name:", profElement.textContent);
    const profData = await makeProfessorData(schedulerProfName);
    profElement.textContent = "";
    profElement.classList.add("rmp-osu-injected");
    const ratingEl = createRatingElement(profData, schedulerProfName);
    profElement.appendChild(ratingEl);
}

async function getInstructorNameForCRN(crn) {
    const cachedInstructor = getCrnToInstructorCache(crn);
    if (cachedInstructor) {
        console.log(`RMP-OSU: Returning cached instructor ${cachedInstructor} for CRN ${crn}`);
        return cachedInstructor;
    }
    const response = await chrome.runtime.sendMessage({
        type: "fetchRequest",
        method: "POST",
        url: "https://classes.oregonstate.edu/api/?page=fose&route=details",
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
            "Content-Type": "application/json",
            "Host": "classes.oregonstate.edu",
        },
        body: `{"key": "crn:${crn}"}`
    });
    if (!response.success) {
        console.error(`RMP-OSU: Failed to fetch instructor for CRN ${crn}: ${response.error}`);
        return null;
    }
    const parsed = JSON.parse(response.data);
    const tempDiv = document.createElement("div");
    tempDiv.style.display = "none";
    tempDiv.innerHTML = parsed.instructordetail_html;
    const instructorName = tempDiv.textContent.trim();
    setCrnToInstructorCache(crn, instructorName);
    return instructorName;
}

function getSectionTitleRow() {
    const result = document.querySelector(".course-sections > div:first-child");
    // For some reason after the title row gets marked with rmp-osu-inject so
    // it doesn't add the columns again, this selector just can't find it
    // Doesn't really matter bc it still prevents columns being added again ig
    return result;
}

async function getSectionDataFor(className) {
    const cachedSectionData = getClassNameToSectionDataCache(className);
    if (cachedSectionData) {
        console.log(`RMP-OSU: Returning cached section data for ${className}`);
        return cachedSectionData.allInGroup;
    }
    const response = await chrome.runtime.sendMessage({
        type: "fetchRequest",
        method: "POST",
        url: "https://classes.oregonstate.edu/api/?page=fose&route=details",
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
            "Content-Type": "application/json",
            "Host": "classes.oregonstate.edu",
        },
        body: `{"group": "code:${className}"}`
    });
    if (!response.success) {
        console.error(`RMP-OSU: Failed to fetch section data for ${className}: ${response.error}`);
        return null;
    }
    const parsed = JSON.parse(response.body);
    setClassNameToSectionDataCache(className, parsed);
    return parsed.allInGroup;
}


function createSectionTitleElement(title) {
    //<div role="columnheader" scope="col">Actual Enrl</div>
    const element = document.createElement("div");
    element.role = "columnheader";
    element.scope = "col";
    element.textContent = title;
    return element;
}

function createSectionColValueElement(title) {
    const element = document.createElement("div");
    element.class = `course-section-${title}`
    element.role = "gridcell";
    return element;
}

function getSectionCRN(sectionElement) {
    const crnData = sectionElement.getAttribute("data-key").split(":")[1];
    if (crnData) {
        console.log("RMP-OSU: Found CRN in data-key attribute:", crnData);
        return crnData;
    }
    console.warn("RMP-OSU: CRN not found in data-key, falling back to query selector", sectionElement);
    const crnElement = sectionElement.querySelector(".course-section-crn");
    if (!crnElement) {
        console.warn("RMP-OSU: Failed to find CRN element in section", sectionElement);
        return null;
    }
    let text = ""
    crnElement.childNodes.forEach(node => {
        if (node.nodeType === Node.TEXT_NODE) {
            text += node.nodeValue;
        }
    })
    return text.trim();
}

async function addRMPToSections() {
    const sectionTitles = getSectionTitleRow();
    if (sectionTitles != null) {
        if (!sectionTitles.classList.contains("rmp-osu-injected")) {
            sectionTitles.append(createSectionTitleElement("Instructor"))
            sectionTitles.append(createSectionTitleElement("Rating Count"))
            sectionTitles.classList.add("rmp-osu-injected");
        }
    }
    const sections=  document.querySelectorAll(".course-section")
    console.log(`RMP-OSU: Found ${sections.length} section entries`)
    for (i = 0; i < sections.length; i++) {
        const section = sections[i];
        if (section.classList.contains("rmp-osu-injected")) continue;
        section.classList.add("rmp-osu-injected");
        const crn = getSectionCRN(section);
        const schedulerName = await getInstructorNameForCRN(crn);
        if (schedulerName != null && schedulerName.trim() !== "") {
            const profData = await makeProfessorData(schedulerName);
            if (profData != null) {
                console.log(`RMP-OSU: Got RMP data for section ${crn}:`, profData);
                const instructorValue = createSectionColValueElement("instructor");
                const link = document.createElement("a");
                link.href = profData.getProfLink();
                link.target = "_blank";
                if (profData.numRatings == 0) {
                    link.textContent = `${schedulerName} (No ratings)`;
                }
                else {
                    link.textContent = `${schedulerName} ${profData.avgRating}⭐`;
                }
                instructorValue.appendChild(link);
                const ratingValue = createSectionColValueElement("rating");
                ratingValue.textContent = `${profData.numRatings}`;
                section.append(instructorValue);
                section.append(ratingValue);
                continue
            }
        }
        console.log(`RMP-OSU: No RMP data for section ${crn} with instructor ${schedulerName}`);
        const instructorValue = createSectionColValueElement("instructor");
        const link = document.createElement("p");
        if (schedulerName == null || schedulerName.trim() === "") {
            link.textContent = `(N/A)`;
        }
        else {
            link.textContent = `${schedulerName} (No RMP match)`;
        }
        instructorValue.appendChild(link);
        const ratingValue = createSectionColValueElement("rating");
        ratingValue.textContent = `N/A`;
        section.append(instructorValue);
        section.append(ratingValue);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function main() {
    let backoffMs = 1000;
    const maxBackoffMs = 10000;
    while (true) {
        try {
            await addRMPToClassDescription();
            await addRMPToSections();
            backoffMs = 1000;
            await sleep(1000);
        }
        catch (error) {
            console.error("RMP-OSU: main loop error, backing off. Please report this on github.", error);
            await sleep(backoffMs);
            backoffMs = Math.min(backoffMs * 2, maxBackoffMs);
        }
    }
}

console.log("RMP-OSU: Content script loaded.");
main();
